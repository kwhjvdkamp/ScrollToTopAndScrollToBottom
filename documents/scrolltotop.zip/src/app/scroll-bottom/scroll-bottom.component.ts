import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { DOCUMENT } from "@angular/platform-browser";

@Component({
  selector: 'app-scroll-bottom',
  templateUrl: './scroll-bottom.component.html',
  styleUrls: ['./scroll-bottom.component.css']
})
export class ScrollBottomComponent implements OnInit {

  windowScrolled: boolean;

  constructor(
    @Inject(DOCUMENT) private document: Document) { }

  @HostListener("window:scroll", [])

  onWindowScroll() {
    console.log(`pageYOffset: ${window.pageYOffset}`);
    console.log(`scrollBottom: ${document.documentElement.scrollBottom}`);

    if ( window.pageYOffset 
      || document.documentElement.scrollBottom 
      || document.body.scrollBottom < 100 ) {
        this.windowScrolled = true;
    } 
    else if ( this.windowScrolled && window.pageYOffset 
      || document.documentElement.scrollBottom 
      || document.body.scrollBottom < 10 ) {
        this.windowScrolled = false;
    }
  } 
  
  scrollToBottom() {
    
    (function smoothscroll() {
      var currentScroll = 
      document.documentElement.scrollBottom 
        || document.body.scrollBottom;

      console.log(`KLIK-DOWN ${currentScroll}`);

      if (currentScroll > 0) {
        window.requestAnimationFrame(smoothscroll);
        window.scrollTo(1000, 
          currentScroll + 
          (currentScroll / 8)
        );
      }
    })();
  }

  ngOnInit() {
  }

}